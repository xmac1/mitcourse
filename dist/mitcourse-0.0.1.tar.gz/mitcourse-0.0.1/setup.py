import setuptools

setuptools.setup(
    name='mitcourse',
    version='0.0.1',
    author='xmac',
    author_email='1743164928xmac93@gmail.com',
    description='mitcourse course graph',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.4",
)